class LineSearchFailError(Exception):
    pass


class NotTangentVectorError(Exception):
    pass
